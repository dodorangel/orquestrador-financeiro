import React from 'react';

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Orquestrador Financeiro - Teste</h1>
      <p>Se você está vendo isso, o React está funcionando!</p>
      <button onClick={() => alert('Botão funcionando!')}>
        Testar Interação
      </button>
    </div>
  );
}

export default App;

