import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { bbExtratosService } from './services/bbExtratos.js';
import { categorizationAIService } from './services/categorizationAI.js';
import { supabase } from './config/supabase.js';
import projectionRoutes from './routes/projection.js';
import intelligenceRoutes from './routes/intelligence.js';
import pluggyRoutes from './routes/pluggy.js';
import healthRoutes from './routes/health.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());

// Health check simples
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Orquestrador Open Finance API' });
});

// Rotas de Health Check detalhado
app.use('/api/health', healthRoutes);

// Rotas de projeção
app.use('/api/projection', projectionRoutes);

// Rotas de inteligência (IA)
app.use('/api/intelligence', intelligenceRoutes);

// Rotas Pluggy (Open Finance)
app.use('/api/pluggy', pluggyRoutes);

// ============================================
// ROTAS DE SINCRONIZAÇÃO
// ============================================

/**
 * POST /api/sync/bb/extratos
 * Sincroniza extratos do Banco do Brasil
 */
app.post('/api/sync/bb/extratos', async (req, res) => {
  try {
    const { userId, accountId, dataInicio, dataFim } = req.body;

    if (!userId || !accountId) {
      return res.status(400).json({ error: 'userId e accountId são obrigatórios' });
    }

    // Se não informar datas, sincroniza últimos 30 dias
    let resultado;
    if (!dataInicio || !dataFim) {
      resultado = await bbExtratosService.syncUltimos30Dias(userId, accountId);
    } else {
      resultado = await bbExtratosService.syncExtratos(userId, accountId, dataInicio, dataFim);
    }

    res.json({
      success: true,
      message: 'Sincronização concluída com sucesso',
      data: resultado
    });
  } catch (error) {
    console.error('Erro na sincronização:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

/**
 * GET /api/sync/logs
 * Lista logs de sincronização
 */
app.get('/api/sync/logs', async (req, res) => {
  try {
    const { userId } = req.query;

    const { data, error } = await supabase
      .from('sync_logs')
      .select('*')
      .eq('user_id', userId)
      .order('started_at', { ascending: false })
      .limit(20);

    if (error) throw error;

    res.json({ success: true, data });
  } catch (error) {
    console.error('Erro ao buscar logs:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ROTAS DE TRANSAÇÕES
// ============================================

/**
 * GET /api/transactions
 * Lista transações
 */
app.get('/api/transactions', async (req, res) => {
  try {
    const { userId, accountId, startDate, endDate, limit = 100 } = req.query;

    let query = supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false })
      .limit(parseInt(limit));

    if (accountId) {
      query = query.eq('account_id', accountId);
    }

    if (startDate) {
      query = query.gte('date', startDate);
    }

    if (endDate) {
      query = query.lte('date', endDate);
    }

    const { data, error } = await query;

    if (error) throw error;

    res.json({ success: true, data });
  } catch (error) {
    console.error('Erro ao buscar transações:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/transactions/summary
 * Resumo financeiro
 */
app.get('/api/transactions/summary', async (req, res) => {
  try {
    const { userId, startDate, endDate } = req.query;

    // Busca transações do período
    let query = supabase
      .from('transactions')
      .select('type, amount')
      .eq('user_id', userId)
      .eq('status', 'completed');

    if (startDate) query = query.gte('date', startDate);
    if (endDate) query = query.lte('date', endDate);

    const { data, error } = await query;

    if (error) throw error;

    // Calcula totais
    const summary = data.reduce((acc, t) => {
      if (t.type === 'income') {
        acc.totalIncome += t.amount;
      } else {
        acc.totalExpense += t.amount;
      }
      return acc;
    }, { totalIncome: 0, totalExpense: 0 });

    summary.balance = summary.totalIncome - summary.totalExpense;
    summary.transactionCount = data.length;

    res.json({ success: true, data: summary });
  } catch (error) {
    console.error('Erro ao calcular resumo:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ROTAS DE CATEGORIZAÇÃO IA
// ============================================

/**
 * POST /api/categorize/transaction
 * Categoriza uma transação específica
 */
app.post('/api/categorize/transaction', async (req, res) => {
  try {
    const { transactionId } = req.body;

    // Busca a transação
    const { data: transaction, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('id', transactionId)
      .single();

    if (error) throw error;

    // Categoriza
    const result = await categorizationAIService.categorizeTransaction(transaction);

    if (result) {
      // Atualiza no banco
      await supabase
        .from('transactions')
        .update({
          category_id: result.category_id,
          is_categorized_by_ai: result.is_ai_categorized
        })
        .eq('id', transactionId);
    }

    res.json({ success: true, data: result });
  } catch (error) {
    console.error('Erro ao categorizar:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/categorize/batch
 * Categoriza múltiplas transações
 */
app.post('/api/categorize/batch', async (req, res) => {
  try {
    const { userId, limit = 100 } = req.body;

    // Busca transações não categorizadas
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .is('category_id', null)
      .limit(limit);

    if (error) throw error;

    // Categoriza em lote
    const results = await categorizationAIService.categorizeBatch(transactions);

    const summary = {
      total: results.length,
      categorized: results.filter(r => r.updated).length,
      skipped: results.filter(r => r.skipped).length,
      failed: results.filter(r => !r.updated && !r.skipped).length
    };

    res.json({ success: true, data: summary, details: results });
  } catch (error) {
    console.error('Erro ao categorizar em lote:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/categorize/detect-installments
 * Detecta parcelas de cartão
 */
app.post('/api/categorize/detect-installments', async (req, res) => {
  try {
    const { userId } = req.body;

    // Busca transações dos últimos 12 meses
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .gte('date', oneYearAgo.toISOString().split('T')[0])
      .is('installment_id', null);

    if (error) throw error;

    // Detecta parcelas
    const installments = await categorizationAIService.detectInstallments(transactions);

    res.json({
      success: true,
      data: {
        installmentsDetected: installments.length,
        installments
      }
    });
  } catch (error) {
    console.error('Erro ao detectar parcelas:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ROTAS DE CATEGORIAS
// ============================================

/**
 * GET /api/categories
 * Lista categorias
 */
app.get('/api/categories', async (req, res) => {
  try {
    const { userId } = req.query;

    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .or(`is_system.eq.true,user_id.eq.${userId}`)
      .order('name');

    if (error) throw error;

    res.json({ success: true, data });
  } catch (error) {
    console.error('Erro ao buscar categorias:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// INICIAR SERVIDOR
// ============================================

app.listen(PORT, () => {
  console.log('');
  console.log('🚀 ========================================');
  console.log('🚀  Orquestrador Open Finance API');
  console.log('🚀 ========================================');
  console.log(`🚀  Servidor rodando na porta ${PORT}`);
  console.log(`🚀  http://localhost:${PORT}`);
  console.log('🚀 ========================================');
  console.log('');
});

