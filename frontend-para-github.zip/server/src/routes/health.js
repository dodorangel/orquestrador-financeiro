import express from 'express';
import { supabase } from '../config/supabase.js';
import OpenAI from 'openai';

const router = express.Router();

// Health check geral
router.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Backend está online',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Health check do banco de dados
router.get('/database', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('count')
      .limit(1);
    
    if (error) throw error;
    
    res.json({
      success: true,
      message: 'Banco de dados conectado',
      service: 'Supabase'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao conectar com banco de dados',
      error: error.message
    });
  }
});

// Health check da OpenAI
router.get('/openai', async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey) {
      throw new Error('API Key não configurada');
    }
    
    const openai = new OpenAI({ apiKey });
    
    // Teste simples
    const completion = await openai.chat.completions.create({
      model: 'gpt-4.1-mini',
      messages: [{ role: 'user', content: 'test' }],
      max_tokens: 5
    });
    
    res.json({
      success: true,
      message: 'OpenAI API configurada e funcional',
      model: 'gpt-4.1-mini'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao conectar com OpenAI',
      error: error.message
    });
  }
});

// Health check do Pluggy
router.get('/pluggy', async (req, res) => {
  try {
    const clientId = process.env.PLUGGY_CLIENT_ID;
    const clientSecret = process.env.PLUGGY_CLIENT_SECRET;
    
    if (!clientId || !clientSecret) {
      throw new Error('Credenciais Pluggy não configuradas');
    }
    
    res.json({
      success: true,
      message: 'Pluggy configurado',
      clientId: clientId.substring(0, 8) + '...'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro na configuração do Pluggy',
      error: error.message
    });
  }
});

export default router;

