import axios from 'axios';
import dotenv from 'dotenv';
import { supabase } from '../config/supabase.js';

dotenv.config();

const BB_API_BASE = process.env.BB_API_BASE_URL || 'https://api.hm.bb.com.br';
const BB_APP_KEY = process.env.BB_APP_KEY;
const BB_CLIENT_ID = process.env.BB_CLIENT_ID;
const BB_CLIENT_SECRET = process.env.BB_CLIENT_SECRET;
const BB_BASIC_AUTH = process.env.BB_BASIC_AUTH;

/**
 * Serviço de Autenticação OAuth2 com Banco do Brasil
 */
class BBAuthService {
  constructor() {
    this.tokenCache = null;
    this.tokenExpiresAt = null;
  }

  /**
   * Obtém um token de acesso válido
   * Usa cache se o token ainda estiver válido
   */
  async getAccessToken(userId) {
    // Verifica se há token em cache válido
    if (this.tokenCache && this.tokenExpiresAt && new Date() < this.tokenExpiresAt) {
      console.log('✅ Usando token em cache');
      return this.tokenCache;
    }

    // Tenta buscar token do banco de dados
    const { data: storedToken, error } = await supabase
      .from('bb_tokens')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (!error && storedToken && new Date(storedToken.expires_at) > new Date()) {
      console.log('✅ Token válido encontrado no banco de dados');
      this.tokenCache = storedToken.access_token;
      this.tokenExpiresAt = new Date(storedToken.expires_at);
      return this.tokenCache;
    }

    // Precisa obter novo token
    console.log('🔄 Obtendo novo token de acesso...');
    return await this.requestNewToken(userId);
  }

  /**
   * Solicita um novo token de acesso ao BB
   */
  async requestNewToken(userId) {
    try {
      const response = await axios.post(
        `${BB_API_BASE}/oauth/token`,
        new URLSearchParams({
          grant_type: 'client_credentials',
          scope: 'extratos.read'
        }),
        {
          headers: {
            'Authorization': `Basic ${BB_BASIC_AUTH}`,
            'Content-Type': 'application/x-www-form-urlencoded',
            'gw-dev-app-key': BB_APP_KEY
          }
        }
      );

      const { access_token, token_type, expires_in, scope } = response.data;

      // Calcula quando o token expira
      const expiresAt = new Date();
      expiresAt.setSeconds(expiresAt.getSeconds() + expires_in);

      // Salva no cache
      this.tokenCache = access_token;
      this.tokenExpiresAt = expiresAt;

      // Salva no banco de dados
      await supabase
        .from('bb_tokens')
        .upsert({
          user_id: userId,
          access_token,
          token_type,
          expires_at: expiresAt.toISOString(),
          scope
        }, {
          onConflict: 'user_id'
        });

      console.log('✅ Novo token obtido e salvo com sucesso!');
      console.log(`   Expira em: ${expiresAt.toLocaleString('pt-BR')}`);

      return access_token;
    } catch (error) {
      console.error('❌ Erro ao obter token de acesso:', error.response?.data || error.message);
      throw new Error('Falha na autenticação com o Banco do Brasil');
    }
  }

  /**
   * Revoga o token atual (logout)
   */
  async revokeToken(userId) {
    this.tokenCache = null;
    this.tokenExpiresAt = null;

    await supabase
      .from('bb_tokens')
      .delete()
      .eq('user_id', userId);

    console.log('✅ Token revogado com sucesso');
  }
}

export const bbAuthService = new BBAuthService();

