import React from 'react';
import DashboardCompleto from './components/DashboardCompleto';

function App() {
  return <DashboardCompleto />;
}

export default App;

