import OpenAI from 'openai';
import { supabase } from '../config/supabase.js';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

/**
 * Serviço de Análise Inteligente com OpenAI
 * Analisa dados financeiros e gera insights personalizados
 */

/**
 * Analisa padrões de gastos e gera insights
 */
export async function analyzeSpendingPatterns(userId) {
  try {
    // Buscar transações dos últimos 12 meses
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('date, description, amount, type')
      .eq('user_id', userId)
      .gte('date', new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0])
      .order('date', { ascending: true });

    if (error) throw error;

    // Agrupar por categoria (usando description como proxy)
    const categoryTotals = {};
    const monthlyData = {};

    transactions.forEach(t => {
      const category = t.description;
      const month = t.date.substring(0, 7);

      // Totais por categoria
      if (!categoryTotals[category]) {
        categoryTotals[category] = { total: 0, count: 0, type: t.type };
      }
      categoryTotals[category].total += Number(t.amount);
      categoryTotals[category].count += 1;

      // Dados mensais
      if (!monthlyData[month]) {
        monthlyData[month] = { income: 0, expenses: 0 };
      }
      if (t.type === 'income') {
        monthlyData[month].income += Number(t.amount);
      } else if (t.type === 'expense') {
        monthlyData[month].expenses += Number(t.amount);
      }
    });

    // Preparar dados para análise da IA
    const summary = {
      totalTransactions: transactions.length,
      categories: Object.entries(categoryTotals)
        .filter(([_, data]) => data.type === 'expense')
        .sort((a, b) => b[1].total - a[1].total)
        .slice(0, 10)
        .map(([category, data]) => ({
          category,
          total: data.total,
          average: data.total / data.count,
          count: data.count
        })),
      monthlyTrend: Object.entries(monthlyData).map(([month, data]) => ({
        month,
        income: data.income,
        expenses: data.expenses,
        balance: data.income - data.expenses
      }))
    };

    // Chamar OpenAI para análise
    const completion = await openai.chat.completions.create({
      model: 'gpt-4.1-mini',
      messages: [
        {
          role: 'system',
          content: `Você é um consultor financeiro especializado em finanças pessoais brasileiras. 
Analise os dados financeiros fornecidos e gere insights práticos e acionáveis.
Seja direto, objetivo e empático. Use linguagem casual e brasileira.
Foque em identificar padrões, oportunidades de economia e alertas importantes.`
        },
        {
          role: 'user',
          content: `Analise estes dados financeiros e gere 5 insights práticos:

Resumo:
- Total de transações: ${summary.totalTransactions}
- Período: últimos 12 meses

Top 10 Categorias de Gastos:
${summary.categories.map((c, i) => `${i + 1}. ${c.category}: R$ ${c.total.toFixed(2)} (${c.count} transações, média R$ ${c.average.toFixed(2)})`).join('\n')}

Tendência Mensal (últimos 6 meses):
${summary.monthlyTrend.slice(-6).map(m => `${m.month}: Receitas R$ ${m.income.toFixed(2)}, Despesas R$ ${m.expenses.toFixed(2)}, Saldo R$ ${m.balance.toFixed(2)}`).join('\n')}

Gere 5 insights no formato JSON:
{
  "insights": [
    {
      "title": "Título curto e impactante",
      "description": "Descrição detalhada do insight",
      "category": "categoria relacionada",
      "type": "warning|opportunity|positive",
      "actionable": "Ação específica que o usuário pode tomar",
      "potentialSaving": valor_em_reais (ou 0 se não aplicável)
    }
  ]
}`
        }
      ],
      temperature: 0.7,
      response_format: { type: 'json_object' }
    });

    const analysis = JSON.parse(completion.choices[0].message.content);

    return {
      success: true,
      data: {
        summary,
        insights: analysis.insights,
        generatedAt: new Date().toISOString()
      }
    };

  } catch (error) {
    console.error('Erro na análise inteligente:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Gera projeção inteligente usando OpenAI
 */
export async function generateIntelligentProjection(userId, months = 6) {
  try {
    // Buscar dados históricos
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('date, amount, type')
      .eq('user_id', userId)
      .order('date', { ascending: true });

    if (error) throw error;

    // Agrupar por mês
    const monthlyData = {};
    transactions.forEach(t => {
      const month = t.date.substring(0, 7);
      if (!monthlyData[month]) {
        monthlyData[month] = { income: 0, expenses: 0 };
      }
      if (t.type === 'income') {
        monthlyData[month].income += Number(t.amount);
      } else if (t.type === 'expense') {
        monthlyData[month].expenses += Number(t.amount);
      }
    });

    const historical = Object.entries(monthlyData).map(([month, data]) => ({
      month,
      income: data.income,
      expenses: data.expenses,
      balance: data.income - data.expenses
    }));

    // Chamar OpenAI para projeção
    const completion = await openai.chat.completions.create({
      model: 'gpt-4.1-mini',
      messages: [
        {
          role: 'system',
          content: `Você é um especialista em análise preditiva financeira.
Analise os dados históricos e gere projeções realistas para os próximos ${months} meses.
Considere tendências, sazonalidade e padrões identificados.
Seja conservador nas projeções de receitas e realista nas despesas.`
        },
        {
          role: 'user',
          content: `Dados históricos (últimos 12 meses):
${historical.slice(-12).map(m => `${m.month}: Receitas R$ ${m.income.toFixed(2)}, Despesas R$ ${m.expenses.toFixed(2)}, Saldo R$ ${m.balance.toFixed(2)}`).join('\n')}

Gere projeções para os próximos ${months} meses no formato JSON:
{
  "projections": [
    {
      "month": "YYYY-MM",
      "income": valor,
      "expenses": valor,
      "balance": valor,
      "confidence": 0.0-1.0,
      "reasoning": "Breve explicação da projeção"
    }
  ],
  "summary": {
    "trend": "increasing|stable|decreasing",
    "avgMonthlyIncome": valor,
    "avgMonthlyExpenses": valor,
    "avgMonthlyBalance": valor,
    "recommendations": ["recomendação 1", "recomendação 2"]
  }
}`
        }
      ],
      temperature: 0.5,
      response_format: { type: 'json_object' }
    });

    const projection = JSON.parse(completion.choices[0].message.content);

    return {
      success: true,
      data: {
        historical: historical.slice(-12),
        ...projection,
        generatedAt: new Date().toISOString()
      }
    };

  } catch (error) {
    console.error('Erro na projeção inteligente:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Detecta anomalias nos gastos
 */
export async function detectAnomalies(userId) {
  try {
    // Buscar transações dos últimos 3 meses
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('date, description, amount, type')
      .eq('user_id', userId)
      .eq('type', 'expense')
      .gte('date', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0])
      .order('date', { ascending: true });

    if (error) throw error;

    // Calcular estatísticas por categoria
    const categoryStats = {};
    transactions.forEach(t => {
      const category = t.description;
      if (!categoryStats[category]) {
        categoryStats[category] = { amounts: [], total: 0, count: 0 };
      }
      categoryStats[category].amounts.push(Number(t.amount));
      categoryStats[category].total += Number(t.amount);
      categoryStats[category].count += 1;
    });

    // Calcular média e desvio padrão
    Object.keys(categoryStats).forEach(category => {
      const amounts = categoryStats[category].amounts;
      const mean = categoryStats[category].total / categoryStats[category].count;
      const variance = amounts.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / amounts.length;
      const stdDev = Math.sqrt(variance);
      
      categoryStats[category].mean = mean;
      categoryStats[category].stdDev = stdDev;
    });

    // Identificar anomalias (valores > 2 desvios padrão da média)
    const anomalies = transactions.filter(t => {
      const category = t.description;
      const stats = categoryStats[category];
      const amount = Number(t.amount);
      return amount > stats.mean + (2 * stats.stdDev);
    });

    // Chamar OpenAI para análise das anomalias
    if (anomalies.length > 0) {
      const completion = await openai.chat.completions.create({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'system',
            content: `Você é um analista de segurança financeira.
Analise as transações anômalas e identifique possíveis problemas ou explicações.
Seja objetivo e direto. Foque em alertar sobre gastos incomuns.`
          },
          {
            role: 'user',
            content: `Transações anômalas detectadas:
${anomalies.map(a => `${a.date} - ${a.description}: R$ ${a.amount}`).join('\n')}

Para cada anomalia, gere uma análise no formato JSON:
{
  "anomalies": [
    {
      "date": "data",
      "description": "descrição",
      "amount": valor,
      "severity": "low|medium|high",
      "possibleReasons": ["razão 1", "razão 2"],
      "recommendation": "recomendação"
    }
  ]
}`
          }
        ],
        temperature: 0.3,
        response_format: { type: 'json_object' }
      });

      const analysis = JSON.parse(completion.choices[0].message.content);

      return {
        success: true,
        data: {
          anomaliesDetected: anomalies.length,
          ...analysis,
          generatedAt: new Date().toISOString()
        }
      };
    }

    return {
      success: true,
      data: {
        anomaliesDetected: 0,
        message: 'Nenhuma anomalia detectada nos últimos 3 meses',
        generatedAt: new Date().toISOString()
      }
    };

  } catch (error) {
    console.error('Erro na detecção de anomalias:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

export default {
  analyzeSpendingPatterns,
  generateIntelligentProjection,
  detectAnomalies
};

