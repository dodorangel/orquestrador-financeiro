import { PluggyClient } from 'pluggy-sdk';
import dotenv from 'dotenv';
import { supabase } from '../config/supabase.js';

dotenv.config();

const PLUGGY_CLIENT_ID = process.env.PLUGGY_CLIENT_ID;
const PLUGGY_CLIENT_SECRET = process.env.PLUGGY_CLIENT_SECRET;

/**
 * Serviço de Integração com Pluggy (Open Finance)
 * Conecta com todos os bancos brasileiros sem precisar de CNPJ
 */
class PluggyService {
  constructor() {
    this.client = new PluggyClient({
      clientId: PLUGGY_CLIENT_ID,
      clientSecret: PLUGGY_CLIENT_SECRET,
    });
  }

  /**
   * Cria um Connect Token para o widget de conexão
   * O usuário usa este token para conectar suas contas bancárias
   */
  async createConnectToken(userId) {
    try {
      console.log('🔗 Criando Connect Token para usuário:', userId);
      
      const connectToken = await this.client.createConnectToken();

      console.log('✅ Connect Token criado com sucesso!');
      console.log(`   Access Token: ${connectToken.accessToken.substring(0, 20)}...`);

      return {
        accessToken: connectToken.accessToken,
        expiresAt: new Date(Date.now() + 30 * 60 * 1000), // 30 minutos
      };
    } catch (error) {
      console.error('❌ Erro ao criar Connect Token:', error.message);
      throw new Error('Falha ao criar token de conexão');
    }
  }

  /**
   * Lista todos os Items (conexões bancárias) do usuário
   * Cada Item representa uma conexão com um banco
   */
  async listItems(userId) {
    try {
      console.log('📋 Listando Items do usuário:', userId);

      const items = await this.client.fetchItems({
        clientUserId: userId,
      });

      console.log(`✅ ${items.results.length} Items encontrados`);

      return items.results.map(item => ({
        id: item.id,
        connector: {
          id: item.connector.id,
          name: item.connector.name,
          institutionUrl: item.connector.institutionUrl,
          imageUrl: item.connector.imageUrl,
        },
        status: item.status,
        executionStatus: item.executionStatus,
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
      }));
    } catch (error) {
      console.error('❌ Erro ao listar Items:', error.message);
      throw new Error('Falha ao listar conexões bancárias');
    }
  }

  /**
   * Busca todas as contas bancárias de um Item
   */
  async getAccounts(itemId) {
    try {
      console.log('🏦 Buscando contas do Item:', itemId);

      const accounts = await this.client.fetchAccounts(itemId);

      console.log(`✅ ${accounts.results.length} contas encontradas`);

      return accounts.results.map(account => ({
        id: account.id,
        type: account.type,
        subtype: account.subtype,
        number: account.number,
        name: account.name,
        balance: account.balance,
        currencyCode: account.currencyCode,
        itemId: account.itemId,
      }));
    } catch (error) {
      console.error('❌ Erro ao buscar contas:', error.message);
      throw new Error('Falha ao buscar contas bancárias');
    }
  }

  /**
   * Busca transações de uma conta específica
   */
  async getTransactions(accountId, from = null, to = null) {
    try {
      console.log('💰 Buscando transações da conta:', accountId);
      console.log(`   Período: ${from || 'início'} até ${to || 'hoje'}`);

      const params = { accountId };
      if (from) params.from = from;
      if (to) params.to = to;

      const transactions = await this.client.fetchTransactions(params);

      console.log(`✅ ${transactions.results.length} transações encontradas`);

      return transactions.results.map(tx => ({
        id: tx.id,
        description: tx.description,
        descriptionRaw: tx.descriptionRaw,
        amount: tx.amount,
        date: tx.date,
        balance: tx.balance,
        category: tx.category,
        accountId: tx.accountId,
        providerCode: tx.providerCode,
        status: tx.status,
        paymentData: tx.paymentData,
      }));
    } catch (error) {
      console.error('❌ Erro ao buscar transações:', error.message);
      throw new Error('Falha ao buscar transações');
    }
  }

  /**
   * Sincroniza dados de um Item (força atualização)
   */
  async syncItem(itemId) {
    try {
      console.log('🔄 Sincronizando Item:', itemId);

      const item = await this.client.updateItem(itemId);

      console.log('✅ Sincronização iniciada!');
      console.log(`   Status: ${item.executionStatus}`);

      return {
        id: item.id,
        status: item.status,
        executionStatus: item.executionStatus,
        updatedAt: item.updatedAt,
      };
    } catch (error) {
      console.error('❌ Erro ao sincronizar Item:', error.message);
      throw new Error('Falha ao sincronizar dados bancários');
    }
  }

  /**
   * Importa transações do Pluggy para o banco de dados local
   */
  async importTransactions(userId, accountId, pluggyAccountId) {
    try {
      console.log('📥 Importando transações para o banco de dados...');
      console.log(`   Usuário: ${userId}`);
      console.log(`   Conta: ${accountId}`);
      console.log(`   Pluggy Account: ${pluggyAccountId}`);

      // Busca transações dos últimos 90 dias
      const to = new Date().toISOString().split('T')[0];
      const from = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      const transactions = await this.getTransactions(pluggyAccountId, from, to);

      console.log(`📊 ${transactions.length} transações para importar`);

      let imported = 0;
      let skipped = 0;
      let errors = 0;

      for (const tx of transactions) {
        try {
          // Verifica se já existe (evita duplicatas)
          const { data: existing } = await supabase
            .from('transactions')
            .select('id')
            .eq('external_id', tx.id)
            .single();

          if (existing) {
            skipped++;
            continue;
          }

          // Determina tipo (receita ou despesa)
          const type = tx.amount >= 0 ? 'receita' : 'despesa';

          // Insere transação
          const { error } = await supabase
            .from('transactions')
            .insert({
              user_id: userId,
              account_id: accountId,
              external_id: tx.id,
              description: tx.description || tx.descriptionRaw,
              amount: Math.abs(tx.amount),
              type: type,
              date: tx.date,
              status: 'concluída',
              metadata: {
                pluggy: {
                  category: tx.category,
                  providerCode: tx.providerCode,
                  balance: tx.balance,
                  paymentData: tx.paymentData,
                },
              },
            });

          if (error) {
            console.error(`   ❌ Erro ao importar transação ${tx.id}:`, error.message);
            errors++;
          } else {
            imported++;
          }
        } catch (err) {
          console.error(`   ❌ Erro ao processar transação ${tx.id}:`, err.message);
          errors++;
        }
      }

      console.log('✅ Importação concluída!');
      console.log(`   Importadas: ${imported}`);
      console.log(`   Ignoradas (duplicatas): ${skipped}`);
      console.log(`   Erros: ${errors}`);

      // Registra log de sincronização
      await supabase
        .from('sync_logs')
        .insert({
          user_id: userId,
          source: 'pluggy',
          status: errors === 0 ? 'sucesso' : 'parcial',
          transactions_count: imported,
          metadata: {
            total: transactions.length,
            imported,
            skipped,
            errors,
            period: { from, to },
          },
        });

      return {
        success: true,
        total: transactions.length,
        imported,
        skipped,
        errors,
      };
    } catch (error) {
      console.error('❌ Erro ao importar transações:', error.message);

      // Registra log de erro
      await supabase
        .from('sync_logs')
        .insert({
          user_id: userId,
          source: 'pluggy',
          status: 'erro',
          transactions_count: 0,
          error_message: error.message,
        });

      throw new Error('Falha ao importar transações');
    }
  }

  /**
   * Deleta um Item (desconecta banco)
   */
  async deleteItem(itemId) {
    try {
      console.log('🗑️  Deletando Item:', itemId);

      await this.client.deleteItem(itemId);

      console.log('✅ Item deletado com sucesso!');

      return { success: true };
    } catch (error) {
      console.error('❌ Erro ao deletar Item:', error.message);
      throw new Error('Falha ao desconectar banco');
    }
  }
}

export default new PluggyService();

