import axios from 'axios';
import dotenv from 'dotenv';
import { supabase } from '../config/supabase.js';
import { bbAuthService } from './bbAuth.js';

dotenv.config();

const BB_API_BASE = process.env.BB_API_BASE_URL || 'https://api.hm.bb.com.br';
const BB_APP_KEY = process.env.BB_APP_KEY;
const BB_USER_AGENCY = process.env.BB_USER_AGENCY;
const BB_USER_ACCOUNT = process.env.BB_USER_ACCOUNT;

/**
 * Serviço de Sincronização de Extratos do Banco do Brasil
 */
class BBExtratosService {
  
  /**
   * Sincroniza extratos de um período específico
   * @param {string} userId - ID do usuário
   * @param {string} accountId - ID da conta bancária
   * @param {string} dataInicio - Data inicial (DDMMAAAA)
   * @param {string} dataFim - Data final (DDMMAAAA)
   */
  async syncExtratos(userId, accountId, dataInicio, dataFim) {
    console.log(`🔄 Iniciando sincronização de extratos...`);
    console.log(`   Período: ${dataInicio} a ${dataFim}`);

    const syncLog = {
      user_id: userId,
      account_id: accountId,
      status: 'success',
      transactions_imported: 0,
      transactions_updated: 0,
      transactions_skipped: 0,
      started_at: new Date().toISOString(),
      completed_at: null,
      error_message: null
    };

    try {
      // Obtém token de acesso
      const accessToken = await bbAuthService.getAccessToken(userId);

      // Busca extratos (com paginação)
      let pagina = 1;
      let temMaisPaginas = true;
      let totalTransacoes = 0;

      while (temMaisPaginas) {
        console.log(`📄 Buscando página ${pagina}...`);

        const response = await axios.get(
          `${BB_API_BASE}/extratos/v1/conta-corrente/agencia/${BB_USER_AGENCY}/conta/${BB_USER_ACCOUNT}`,
          {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
              'gw-dev-app-key': BB_APP_KEY
            },
            params: {
              dataInicioSolicitacao: dataInicio,
              dataFimSolicitacao: dataFim,
              numeroPaginaSolicitacao: pagina,
              quantidadeRegistroPaginaSolicitacao: 200
            }
          }
        );

        const { listaLancamento, numeroPaginaProximo, quantidadeTotalRegistro } = response.data;

        console.log(`   Encontrados ${listaLancamento.length} lançamentos nesta página`);
        console.log(`   Total de registros: ${quantidadeTotalRegistro}`);

        // Processa cada lançamento
        for (const lancamento of listaLancamento) {
          const resultado = await this.processarLancamento(userId, accountId, lancamento);
          
          if (resultado === 'imported') {
            syncLog.transactions_imported++;
          } else if (resultado === 'updated') {
            syncLog.transactions_updated++;
          } else if (resultado === 'skipped') {
            syncLog.transactions_skipped++;
          }
        }

        totalTransacoes += listaLancamento.length;

        // Verifica se há mais páginas
        temMaisPaginas = numeroPaginaProximo > 0 && numeroPaginaProximo !== pagina;
        pagina = numeroPaginaProximo;
      }

      syncLog.completed_at = new Date().toISOString();
      console.log(`✅ Sincronização concluída!`);
      console.log(`   Total de transações processadas: ${totalTransacoes}`);
      console.log(`   Importadas: ${syncLog.transactions_imported}`);
      console.log(`   Atualizadas: ${syncLog.transactions_updated}`);
      console.log(`   Ignoradas (duplicadas): ${syncLog.transactions_skipped}`);

    } catch (error) {
      console.error('❌ Erro na sincronização:', error.response?.data || error.message);
      syncLog.status = 'error';
      syncLog.error_message = error.message;
      syncLog.completed_at = new Date().toISOString();
      throw error;
    } finally {
      // Salva log de sincronização
      await supabase.from('sync_logs').insert(syncLog);
    }

    return syncLog;
  }

  /**
   * Processa um lançamento individual
   */
  async processarLancamento(userId, accountId, lancamento) {
    // Cria ID externo único para detectar duplicatas
    const externalId = `${lancamento.dataLancamento}-${lancamento.numeroDocumento}-${lancamento.valorLancamento}`;

    // Verifica se já existe
    const { data: existing } = await supabase
      .from('transactions')
      .select('id')
      .eq('account_id', accountId)
      .eq('external_id', externalId)
      .single();

    if (existing) {
      return 'skipped'; // Já existe, pula
    }

    // Determina tipo de transação
    const type = lancamento.indicadorSinalLancamento === 'C' ? 'income' : 'expense';

    // Determina método de pagamento baseado no código de histórico
    const paymentMethod = this.determinarMetodoPagamento(lancamento.codigoHistorico, lancamento.textoDescricaoHistorico);

    // Converte data (DDMMAAAA -> AAAA-MM-DD)
    const date = this.converterData(lancamento.dataLancamento);

    // Prepara dados da transação
    const transaction = {
      user_id: userId,
      account_id: accountId,
      external_id: externalId,
      type,
      amount: Math.abs(lancamento.valorLancamento),
      description: lancamento.textoDescricaoHistorico || 'Transação',
      date,
      status: lancamento.indicadorTipoLancamento === '1' ? 'completed' : 'pending',
      payment_method: paymentMethod,
      
      // Dados da contrapartida
      counterparty_name: null,
      counterparty_document: lancamento.numeroCpfCnpjContrapartida || null,
      counterparty_bank: lancamento.codigoBancoContrapartida || null,
      counterparty_agency: lancamento.codigoAgenciaContrapartida || null,
      counterparty_account: lancamento.numeroContaContrapartida || null,
      
      // Metadados
      history_code: lancamento.codigoHistorico,
      is_recurring: false,
      is_transfer: false,
      is_reviewed: false,
      is_categorized_by_ai: false
    };

    // Insere no banco
    const { error } = await supabase
      .from('transactions')
      .insert(transaction);

    if (error) {
      console.error('❌ Erro ao inserir transação:', error);
      return 'error';
    }

    return 'imported';
  }

  /**
   * Determina o método de pagamento baseado no código de histórico
   */
  determinarMetodoPagamento(codigoHistorico, descricao) {
    const codigo = parseInt(codigoHistorico);
    const desc = descricao?.toUpperCase() || '';

    // PIX
    if (desc.includes('PIX')) return 'pix';
    
    // TED/DOC
    if (desc.includes('TED') || desc.includes('DOC') || desc.includes('TRANSF')) return 'ted';
    
    // Boleto
    if (desc.includes('BOLETO') || desc.includes('PAGAMENTO')) return 'boleto';
    
    // Cartão
    if (desc.includes('CARTAO') || desc.includes('CARTÃO') || desc.includes('DEBITO')) return 'debit_card';
    
    // Baseado no código de histórico (exemplos comuns do BB)
    if (codigo >= 800 && codigo <= 899) return 'pix';
    if (codigo >= 700 && codigo <= 799) return 'ted';
    if (codigo >= 600 && codigo <= 699) return 'boleto';
    
    return 'other';
  }

  /**
   * Converte data de DDMMAAAA para AAAA-MM-DD
   */
  converterData(dataStr) {
    if (!dataStr || dataStr === '0') return null;
    
    const dia = dataStr.substring(0, 2);
    const mes = dataStr.substring(2, 4);
    const ano = dataStr.substring(4, 8);
    
    return `${ano}-${mes}-${dia}`;
  }

  /**
   * Sincroniza os últimos 30 dias
   */
  async syncUltimos30Dias(userId, accountId) {
    const hoje = new Date();
    const dataFim = this.formatarDataBB(hoje);
    
    const inicio = new Date();
    inicio.setDate(inicio.getDate() - 30);
    const dataInicio = this.formatarDataBB(inicio);

    return await this.syncExtratos(userId, accountId, dataInicio, dataFim);
  }

  /**
   * Formata data para o formato do BB (DDMMAAAA)
   */
  formatarDataBB(date) {
    const dia = String(date.getDate()).padStart(2, '0');
    const mes = String(date.getMonth() + 1).padStart(2, '0');
    const ano = date.getFullYear();
    return `${dia}${mes}${ano}`;
  }
}

export const bbExtratosService = new BBExtratosService();

