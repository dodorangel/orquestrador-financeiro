import OpenAI from 'openai';
import dotenv from 'dotenv';
import { supabase } from '../config/supabase.js';

dotenv.config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || 'sk-dummy-key-for-testing'
});

/**
 * Serviço de Categorização Inteligente com IA
 */
class CategorizationAIService {
  
  /**
   * Categoriza uma transação usando IA
   */
  async categorizeTransaction(transaction) {
    try {
      // Busca categorias disponíveis
      const { data: categories } = await supabase
        .from('categories')
        .select('id, name, parent_id')
        .eq('is_system', true);

      // Prepara lista de categorias para a IA
      const categoryList = categories
        .filter(c => !c.parent_id) // Apenas categorias principais
        .map(c => c.name)
        .join(', ');

      // Prompt para a IA
      const prompt = `Você é um assistente especializado em categorização de transações financeiras brasileiras.

Analise a seguinte transação e sugira a categoria mais adequada:

Descrição: ${transaction.description}
Valor: R$ ${transaction.amount}
Tipo: ${transaction.type === 'expense' ? 'Despesa' : 'Receita'}
Método: ${transaction.payment_method || 'Não especificado'}

Categorias disponíveis: ${categoryList}

Responda APENAS com o nome da categoria, sem explicações adicionais.`;

      const response = await openai.chat.completions.create({
        model: 'gpt-4.1-mini',
        messages: [
          {
            role: 'system',
            content: 'Você é um especialista em finanças pessoais que categoriza transações de forma precisa e consistente.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 50
      });

      const suggestedCategory = response.choices[0].message.content.trim();

      // Busca o ID da categoria sugerida
      const { data: category } = await supabase
        .from('categories')
        .select('id')
        .eq('name', suggestedCategory)
        .eq('is_system', true)
        .single();

      if (category) {
        console.log(`✅ IA categorizou "${transaction.description}" como "${suggestedCategory}"`);
        return {
          category_id: category.id,
          category_name: suggestedCategory,
          confidence: 0.85,
          is_ai_categorized: true
        };
      }

      // Se não encontrou a categoria, tenta categorização por regras
      return await this.categorizeByRules(transaction);

    } catch (error) {
      console.error('❌ Erro na categorização com IA:', error.message);
      // Fallback para categorização por regras
      return await this.categorizeByRules(transaction);
    }
  }

  /**
   * Categoriza por regras (fallback)
   */
  async categorizeByRules(transaction) {
    const description = transaction.description.toUpperCase();

    // Busca regras de categorização
    const { data: rules } = await supabase
      .from('categorization_rules')
      .select('keyword, category_id, confidence')
      .order('confidence', { ascending: false });

    if (!rules) {
      return null;
    }

    // Encontra a primeira regra que match
    for (const rule of rules) {
      if (description.includes(rule.keyword.toUpperCase())) {
        const { data: category } = await supabase
          .from('categories')
          .select('name')
          .eq('id', rule.category_id)
          .single();

        console.log(`✅ Regra categorizou "${transaction.description}" como "${category.name}"`);

        return {
          category_id: rule.category_id,
          category_name: category?.name,
          confidence: rule.confidence / 100,
          is_ai_categorized: false
        };
      }
    }

    return null;
  }

  /**
   * Categoriza múltiplas transações em lote
   */
  async categorizeBatch(transactions) {
    const results = [];

    for (const transaction of transactions) {
      // Pula se já está categorizada
      if (transaction.category_id) {
        results.push({ ...transaction, skipped: true });
        continue;
      }

      const categorization = await this.categorizeTransaction(transaction);

      if (categorization) {
        // Atualiza no banco
        await supabase
          .from('transactions')
          .update({
            category_id: categorization.category_id,
            is_categorized_by_ai: categorization.is_ai_categorized
          })
          .eq('id', transaction.id);

        results.push({
          ...transaction,
          ...categorization,
          updated: true
        });
      } else {
        results.push({ ...transaction, updated: false });
      }

      // Pequeno delay para não sobrecarregar a API
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    return results;
  }

  /**
   * Detecta parcelas de cartão
   */
  async detectInstallments(transactions) {
    const installments = [];

    // Agrupa transações por descrição similar
    const groups = {};

    for (const transaction of transactions) {
      // Extrai padrão de parcela (ex: "1/12", "01/12", "1 de 12")
      const match = transaction.description.match(/(\d{1,2})\s*[\/de]+\s*(\d{1,2})/i);

      if (match) {
        const currentInstallment = parseInt(match[1]);
        const totalInstallments = parseInt(match[2]);

        // Remove o padrão de parcela da descrição para agrupar
        const baseDescription = transaction.description
          .replace(/\d{1,2}\s*[\/de]+\s*\d{1,2}/gi, '')
          .trim();

        const key = `${baseDescription}-${transaction.amount}`;

        if (!groups[key]) {
          groups[key] = [];
        }

        groups[key].push({
          ...transaction,
          currentInstallment,
          totalInstallments,
          baseDescription
        });
      }
    }

    // Processa grupos de parcelas
    for (const [key, group] of Object.entries(groups)) {
      if (group.length >= 2) {
        // Ordena por número da parcela
        group.sort((a, b) => a.currentInstallment - b.currentInstallment);

        const firstTransaction = group[0];

        // Cria registro de parcelamento
        const { data: installment } = await supabase
          .from('installments')
          .insert({
            user_id: firstTransaction.user_id,
            account_id: firstTransaction.account_id,
            description: firstTransaction.baseDescription,
            total_amount: firstTransaction.amount * firstTransaction.totalInstallments,
            installment_amount: firstTransaction.amount,
            total_installments: firstTransaction.totalInstallments,
            paid_installments: group.length,
            start_date: firstTransaction.date,
            category_id: firstTransaction.category_id
          })
          .select()
          .single();

        if (installment) {
          // Vincula transações ao parcelamento
          for (const trans of group) {
            await supabase
              .from('transactions')
              .update({ installment_id: installment.id })
              .eq('id', trans.id);
          }

          installments.push(installment);
          console.log(`✅ Detectado parcelamento: ${firstTransaction.baseDescription} (${group.length}/${firstTransaction.totalInstallments})`);
        }
      }
    }

    return installments;
  }

  /**
   * Aprende com correção do usuário
   */
  async learnFromCorrection(transactionId, oldCategoryId, newCategoryId) {
    // Busca a transação
    const { data: transaction } = await supabase
      .from('transactions')
      .select('description')
      .eq('id', transactionId)
      .single();

    if (!transaction) return;

    // Extrai palavras-chave da descrição
    const keywords = transaction.description
      .toUpperCase()
      .split(/\s+/)
      .filter(word => word.length > 3);

    // Adiciona ou atualiza regras
    for (const keyword of keywords) {
      await supabase
        .from('categorization_rules')
        .upsert({
          keyword,
          category_id: newCategoryId,
          confidence: 95 // Alta confiança pois foi correção manual
        }, {
          onConflict: 'keyword,category_id'
        });
    }

    console.log(`✅ Aprendizado: "${transaction.description}" → nova categoria`);
  }
}

export const categorizationAIService = new CategorizationAIService();

