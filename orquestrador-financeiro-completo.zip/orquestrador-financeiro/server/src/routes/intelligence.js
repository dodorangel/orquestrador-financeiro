import express from 'express';
import {
  analyzeSpendingPatterns,
  generateIntelligentProjection,
  detectAnomalies
} from '../services/intelligentAnalysis.js';

const router = express.Router();

/**
 * GET /api/intelligence/analyze
 * Analisa padrões de gastos e gera insights
 */
router.get('/analyze', async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'userId é obrigatório' });
    }

    console.log(`[Intelligence] Analisando padrões de gastos para usuário ${userId}`);

    const result = await analyzeSpendingPatterns(userId);

    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json(result.data);

  } catch (error) {
    console.error('[Intelligence] Erro na análise:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/intelligence/project
 * Gera projeção inteligente usando IA
 */
router.get('/project', async (req, res) => {
  try {
    const { userId, months = 6 } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'userId é obrigatório' });
    }

    console.log(`[Intelligence] Gerando projeção para usuário ${userId} (${months} meses)`);

    const result = await generateIntelligentProjection(userId, parseInt(months));

    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json(result.data);

  } catch (error) {
    console.error('[Intelligence] Erro na projeção:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/intelligence/anomalies
 * Detecta anomalias nos gastos
 */
router.get('/anomalies', async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'userId é obrigatório' });
    }

    console.log(`[Intelligence] Detectando anomalias para usuário ${userId}`);

    const result = await detectAnomalies(userId);

    if (!result.success) {
      return res.status(500).json({ error: result.error });
    }

    res.json(result.data);

  } catch (error) {
    console.error('[Intelligence] Erro na detecção de anomalias:', error);
    res.status(500).json({ error: error.message });
  }
});

export default router;

