import express from 'express';
import { supabase } from '../config/supabase.js';

const router = express.Router();

// Calcular projeção baseada em média móvel
function calculateProjection(historicalData, months = 6) {
  if (historicalData.length < 3) {
    return [];
  }
  
  // Pegar últimos 3 meses para média móvel
  const lastThreeMonths = historicalData.slice(-3);
  const avgIncome = lastThreeMonths.reduce((sum, m) => sum + m.income, 0) / 3;
  const avgExpenses = lastThreeMonths.reduce((sum, m) => sum + m.expenses, 0) / 3;
  
  // Calcular tendência (regressão linear simples)
  const incomeTrend = (lastThreeMonths[2].income - lastThreeMonths[0].income) / 2;
  const expensesTrend = (lastThreeMonths[2].expenses - lastThreeMonths[0].expenses) / 2;
  
  // Gerar projeções
  const projections = [];
  const lastMonth = new Date(historicalData[historicalData.length - 1].month + '-01');
  
  for (let i = 1; i <= months; i++) {
    const projectionDate = new Date(lastMonth);
    projectionDate.setMonth(projectionDate.getMonth() + i);
    
    const projectedIncome = Math.round((avgIncome + (incomeTrend * i)) * 100) / 100;
    const projectedExpenses = Math.round((avgExpenses + (expensesTrend * i)) * 100) / 100;
    
    projections.push({
      month: `${projectionDate.getFullYear()}-${String(projectionDate.getMonth() + 1).padStart(2, '0')}`,
      income: projectedIncome,
      expenses: projectedExpenses,
      balance: projectedIncome - projectedExpenses,
      isProjection: true,
      confidence: Math.max(0.5, 1 - (i * 0.1)) // Confiança diminui com o tempo
    });
  }
  
  return projections;
}

// GET /api/projection/timeline
// Retorna dados históricos + projeção para gráfico de evolução temporal
router.get('/timeline', async (req, res) => {
  try {
    const { userId, months = 6 } = req.query;
    
    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'userId is required'
      });
    }
    
    // Buscar transações agrupadas por mês
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('date, type, amount')
      .eq('user_id', userId)
      .order('date', { ascending: true });
    
    if (error) throw error;
    
    // Agrupar por mês
    const monthlyData = {};
    
    transactions.forEach(t => {
      const month = t.date.substring(0, 7); // YYYY-MM
      
      if (!monthlyData[month]) {
        monthlyData[month] = { month, income: 0, expenses: 0, isProjection: false };
      }
      
      if (t.type === 'income') {
        monthlyData[month].income += Number(t.amount);
      } else if (t.type === 'expense') {
        monthlyData[month].expenses += Number(t.amount);
      }
    });
    
    // Converter para array e calcular saldo
    const historicalData = Object.values(monthlyData).map(m => ({
      ...m,
      balance: m.income - m.expenses
    }));
    
    // Calcular projeções
    const projections = calculateProjection(historicalData, parseInt(months));
    
    // Combinar histórico + projeção
    const timeline = [...historicalData, ...projections];
    
    res.json({
      success: true,
      data: {
        timeline,
        historical: historicalData,
        projected: projections,
        summary: {
          totalMonths: historicalData.length,
          projectedMonths: projections.length,
          avgMonthlyIncome: historicalData.reduce((sum, m) => sum + m.income, 0) / historicalData.length,
          avgMonthlyExpenses: historicalData.reduce((sum, m) => sum + m.expenses, 0) / historicalData.length,
          avgMonthlyBalance: historicalData.reduce((sum, m) => sum + m.balance, 0) / historicalData.length
        }
      }
    });
    
  } catch (error) {
    console.error('Erro ao gerar projeção:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// GET /api/projection/by-category
// Retorna dados históricos por categoria
router.get('/by-category', async (req, res) => {
  try {
    const { userId } = req.query;
    
    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'userId is required'
      });
    }
    
    // Buscar transações com descrição (usamos como categoria temporária)
    const { data: transactions, error } = await supabase
      .from('transactions')
      .select('date, description, type, amount')
      .eq('user_id', userId)
      .eq('type', 'expense')
      .order('date', { ascending: true });
    
    if (error) throw error;
    
    // Agrupar por categoria e mês
    const categoryData = {};
    
    transactions.forEach(t => {
      const month = t.date.substring(0, 7); // YYYY-MM
      const category = t.description;
      
      if (!categoryData[category]) {
        categoryData[category] = {};
      }
      
      if (!categoryData[category][month]) {
        categoryData[category][month] = 0;
      }
      
      categoryData[category][month] += Number(t.amount);
    });
    
    // Converter para formato de tabela
    const categories = Object.keys(categoryData).map(category => {
      const months = categoryData[category];
      const values = Object.values(months);
      const total = values.reduce((sum, v) => sum + v, 0);
      const avg = total / values.length;
      
      return {
        category,
        months,
        total,
        average: Math.round(avg * 100) / 100
      };
    });
    
    // Ordenar por total (maior primeiro)
    categories.sort((a, b) => b.total - a.total);
    
    res.json({
      success: true,
      data: {
        categories,
        totalCategories: categories.length
      }
    });
    
  } catch (error) {
    console.error('Erro ao buscar dados por categoria:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

export default router;

