import express from 'express';
import pluggyService from '../services/pluggyService.js';

const router = express.Router();

/**
 * POST /api/pluggy/connect-token
 * Cria um Connect Token para o widget de conexão
 */
router.post('/connect-token', async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'userId é obrigatório',
      });
    }

    const token = await pluggyService.createConnectToken(userId);

    res.json({
      success: true,
      token: token.accessToken,
      expiresAt: token.expiresAt,
    });
  } catch (error) {
    console.error('Erro ao criar Connect Token:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/pluggy/items
 * Lista todos os Items (conexões bancárias) do usuário
 */
router.get('/items', async (req, res) => {
  try {
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'userId é obrigatório',
      });
    }

    const items = await pluggyService.listItems(userId);

    res.json({
      success: true,
      items,
      count: items.length,
    });
  } catch (error) {
    console.error('Erro ao listar Items:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/pluggy/accounts/:itemId
 * Busca todas as contas bancárias de um Item
 */
router.get('/accounts/:itemId', async (req, res) => {
  try {
    const { itemId } = req.params;

    const accounts = await pluggyService.getAccounts(itemId);

    res.json({
      success: true,
      accounts,
      count: accounts.length,
    });
  } catch (error) {
    console.error('Erro ao buscar contas:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * GET /api/pluggy/transactions/:accountId
 * Busca transações de uma conta específica
 */
router.get('/transactions/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const { from, to } = req.query;

    const transactions = await pluggyService.getTransactions(accountId, from, to);

    res.json({
      success: true,
      transactions,
      count: transactions.length,
    });
  } catch (error) {
    console.error('Erro ao buscar transações:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/pluggy/sync
 * Sincroniza dados de um Item e importa transações para o banco
 */
router.post('/sync', async (req, res) => {
  try {
    const { userId, accountId, itemId, pluggyAccountId } = req.body;

    if (!userId || !accountId || !itemId || !pluggyAccountId) {
      return res.status(400).json({
        success: false,
        error: 'userId, accountId, itemId e pluggyAccountId são obrigatórios',
      });
    }

    // Força sincronização do Item
    await pluggyService.syncItem(itemId);

    // Aguarda alguns segundos para o Pluggy processar
    await new Promise(resolve => setTimeout(resolve, 5000));

    // Importa transações para o banco de dados
    const result = await pluggyService.importTransactions(userId, accountId, pluggyAccountId);

    res.json({
      success: true,
      ...result,
    });
  } catch (error) {
    console.error('Erro ao sincronizar:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * DELETE /api/pluggy/items/:itemId
 * Deleta um Item (desconecta banco)
 */
router.delete('/items/:itemId', async (req, res) => {
  try {
    const { itemId } = req.params;

    await pluggyService.deleteItem(itemId);

    res.json({
      success: true,
      message: 'Banco desconectado com sucesso',
    });
  } catch (error) {
    console.error('Erro ao deletar Item:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/pluggy/webhook
 * Recebe webhooks do Pluggy (quando dados são atualizados)
 */
router.post('/webhook', async (req, res) => {
  try {
    const event = req.body;

    console.log('📨 Webhook recebido do Pluggy:', event.type);
    console.log('   Item ID:', event.itemId);
    console.log('   Data:', JSON.stringify(event.data, null, 2));

    // Aqui você pode processar diferentes tipos de eventos:
    // - item/created: Novo banco conectado
    // - item/updated: Dados atualizados
    // - item/deleted: Banco desconectado
    // - item/error: Erro na sincronização

    // Por enquanto, apenas loga
    // No futuro, pode disparar sincronização automática

    res.json({ received: true });
  } catch (error) {
    console.error('Erro ao processar webhook:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

export default router;

