import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Credenciais do Supabase
const SUPABASE_URL = 'https://sqetxtcdtkkyptkbzuvn.supabase.co';
const SUPABASE_SERVICE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNxZXR4dGNkdGtreXB0a2J6dXZuIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MjQ1NTQyMSwiZXhwIjoyMDc4MDMxNDIxfQ.u2ggGYFCt7y2tMblN3KEmIDHoZ2I9jL3xZVjdvxk9l0';

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

async function setupDatabase() {
  console.log('🚀 Iniciando configuração do banco de dados...\n');

  try {
    // Lê o arquivo de schema
    const schemaPath = join(__dirname, '..', 'supabase-schema.sql');
    const schemaSQL = readFileSync(schemaPath, 'utf8');

    console.log('📄 Executando schema SQL...');
    
    // Divide o SQL em comandos individuais (separados por ponto e vírgula)
    const commands = schemaSQL
      .split(';')
      .map(cmd => cmd.trim())
      .filter(cmd => cmd.length > 0 && !cmd.startsWith('--'));

    let successCount = 0;
    let errorCount = 0;

    for (const command of commands) {
      try {
        const { error } = await supabase.rpc('exec_sql', { sql: command });
        
        if (error) {
          // Tenta executar diretamente se RPC falhar
          const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/exec_sql`, {
            method: 'POST',
            headers: {
              'apikey': SUPABASE_SERVICE_KEY,
              'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ sql: command })
          });

          if (!response.ok) {
            console.log(`⚠️  Comando ignorado (pode já existir): ${command.substring(0, 50)}...`);
            errorCount++;
          } else {
            successCount++;
          }
        } else {
          successCount++;
        }
      } catch (err) {
        console.log(`⚠️  Erro ao executar comando: ${err.message}`);
        errorCount++;
      }
    }

    console.log(`\n✅ Schema executado!`);
    console.log(`   Sucessos: ${successCount}`);
    console.log(`   Avisos: ${errorCount}\n`);

    // Lê e executa seeds
    const seedsPath = join(__dirname, '..', 'supabase-seeds.sql');
    const seedsSQL = readFileSync(seedsPath, 'utf8');

    console.log('🌱 Executando seeds...');
    
    const seedCommands = seedsSQL
      .split(';')
      .map(cmd => cmd.trim())
      .filter(cmd => cmd.length > 0 && !cmd.startsWith('--'));

    let seedSuccess = 0;
    let seedErrors = 0;

    for (const command of seedCommands) {
      try {
        const { error } = await supabase.rpc('exec_sql', { sql: command });
        
        if (error) {
          console.log(`⚠️  Seed ignorado (pode já existir)`);
          seedErrors++;
        } else {
          seedSuccess++;
        }
      } catch (err) {
        seedErrors++;
      }
    }

    console.log(`\n✅ Seeds executados!`);
    console.log(`   Sucessos: ${seedSuccess}`);
    console.log(`   Avisos: ${seedErrors}\n`);

    // Testa a conexão listando tabelas
    console.log('🔍 Verificando tabelas criadas...');
    
    const tables = [
      'users', 'bank_accounts', 'transactions', 'categories',
      'tags', 'installments', 'recurring_expenses', 'category_limits',
      'alerts', 'sync_logs', 'bb_tokens'
    ];

    for (const table of tables) {
      const { count, error } = await supabase
        .from(table)
        .select('*', { count: 'exact', head: true });

      if (!error) {
        console.log(`   ✅ ${table}: OK`);
      } else {
        console.log(`   ❌ ${table}: ${error.message}`);
      }
    }

    console.log('\n🎉 Banco de dados configurado com sucesso!\n');

  } catch (error) {
    console.error('\n❌ Erro na configuração:', error.message);
    process.exit(1);
  }
}

setupDatabase();

