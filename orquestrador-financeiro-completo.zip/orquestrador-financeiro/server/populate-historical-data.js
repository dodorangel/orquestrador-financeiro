import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const userId = '50ab65c7-e7ad-4858-8d2e-723cba7d0842';
const accountId = 'a0dc2ab4-a61d-4a40-8418-719de2bd6e45';

// Dados históricos baseados nas planilhas do usuário (Jan-Nov 2025)
const historicalData = {
  // Receitas mensais
  income: {
    'jan': 20502, 'fev': 19982, 'mar': 18482, 'abr': 14482, 'mai': 14482,
    'jun': 14482, 'jul': 14482, 'ago': 19982, 'set': 14482, 'out': 19982, 'nov': 14482
  },
  
  // Despesas por categoria
  expenses: {
    // Dívidas
    dividas: {
      'jan': 1336, 'fev': 2967, 'mar': 2967, 'abr': 2967, 'mai': 2967,
      'jun': 4317, 'jul': 4317, 'ago': 4317, 'set': 2685, 'out': 2685, 'nov': 2685
    },
    
    // Impostos/Taxas
    impostos: {
      'jan': 0, 'fev': 975, 'mar': 975, 'abr': 975, 'mai': 1155,
      'jun': 1155, 'jul': 1155, 'ago': 180, 'set': 180, 'out': 180, 'nov': 0
    },
    
    // Educação
    educacao: {
      'jan': 3867, 'fev': 2346, 'mar': 2231, 'abr': 2169, 'mai': 1961,
      'jun': 1644, 'jul': 1644, 'ago': 1644, 'set': 1644, 'out': 1644, 'nov': 1644
    },
    
    // Compras parceladas
    compras_parceladas: {
      'jan': 2733, 'fev': 1840, 'mar': 1532, 'abr': 1172, 'mai': 439,
      'jun': 294, 'jul': 294, 'ago': 173, 'set': 70, 'out': 0, 'nov': 0
    },
    
    // Despesas diárias (Supermercado + Restaurantes + Lazer)
    despesas_diarias: {
      'jan': 13794, 'fev': 5366, 'mar': 3790, 'abr': 3790, 'mai': 3790,
      'jun': 3790, 'jul': 3790, 'ago': 3790, 'set': 3790, 'out': 3790, 'nov': 3790
    },
    
    // Presentes
    presentes: {
      'jan': 568, 'fev': 568, 'mar': 568, 'abr': 568, 'mai': 568,
      'jun': 568, 'jul': 0, 'ago': 0, 'set': 0, 'out': 0, 'nov': 0
    },
    
    // Saúde
    saude: {
      'jan': 1390, 'fev': 666, 'mar': 350, 'abr': 350, 'mai': 350,
      'jun': 350, 'jul': 350, 'ago': 350, 'set': 350, 'out': 350, 'nov': 350
    },
    
    // Casa
    casa: {
      'jan': 3275, 'fev': 3475, 'mar': 3342, 'abr': 3219, 'mai': 3219,
      'jun': 3219, 'jul': 3219, 'ago': 3219, 'set': 2260, 'out': 2260, 'nov': 2260
    },
    
    // Seguro
    seguro: {
      'jan': 576, 'fev': 297, 'mar': 297, 'abr': 575, 'mai': 575,
      'jun': 278, 'jul': 278, 'ago': 575, 'set': 575, 'out': 575, 'nov': 575
    },
    
    // Animais de estimação
    pets: {
      'jan': 1001, 'fev': 484, 'mar': 470, 'abr': 300, 'mai': 300,
      'jun': 300, 'jul': 300, 'ago': 300, 'set': 300, 'out': 300, 'nov': 300
    },
    
    // Tecnologia
    tecnologia: {
      'jan': 482, 'fev': 133, 'mar': 133, 'abr': 133, 'mai': 133,
      'jun': 133, 'jul': 133, 'ago': 133, 'set': 133, 'out': 133, 'nov': 133
    },
    
    // Transporte
    transporte: {
      'jan': 1395, 'fev': 2250, 'mar': 1400, 'abr': 1400, 'mai': 1400,
      'jun': 1400, 'jul': 1400, 'ago': 1100, 'set': 800, 'out': 800, 'nov': 800
    },
    
    // Viagens
    viagens: {
      'jan': 73, 'fev': 0, 'mar': 0, 'abr': 0, 'mai': 0,
      'jun': 750, 'jul': 750, 'ago': 0, 'set': 0, 'out': 0, 'nov': 2000
    },
    
    // Serviços de utilidade pública
    servicos_publicos: {
      'jan': 913, 'fev': 965, 'mar': 765, 'abr': 765, 'mai': 765,
      'jun': 765, 'jul': 765, 'ago': 765, 'set': 765, 'out': 765, 'nov': 765
    },
    
    // Outros
    outros: {
      'jan': 43, 'fev': 200, 'mar': 200, 'abr': 200, 'mai': 200,
      'jun': 200, 'jul': 200, 'ago': 200, 'set': 200, 'out': 200, 'nov': 200
    }
  }
};

const months = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov'];
const monthNumbers = { jan: 1, fev: 2, mar: 3, abr: 4, mai: 5, jun: 6, jul: 7, ago: 8, set: 9, out: 10, nov: 11 };

async function populateHistoricalData() {
  console.log('🚀 Iniciando população de dados históricos...\n');
  
  let totalTransactions = 0;
  
  for (const month of months) {
    const monthNum = monthNumbers[month];
    const year = 2025;
    const date = `${year}-${String(monthNum).padStart(2, '0')}-15`; // Dia 15 de cada mês
    
    console.log(`📅 Processando ${month}/${year}...`);
    
    // Inserir receita
    const incomeAmount = historicalData.income[month];
    if (incomeAmount > 0) {
      const { error: incomeError } = await supabase
        .from('transactions')
        .insert({
          user_id: userId,
          account_id: accountId,
          date: date,
          description: 'SALARIO SERVIDOR PUBLICO',
          amount: incomeAmount,
          type: 'income',
          category: 'Salário',
          subcategory: 'Servidor Público',
          payment_method: 'bank_transfer',
          status: 'completed',
          is_recurring: true
        });
      
      if (incomeError) {
        console.error(`❌ Erro ao inserir receita de ${month}:`, incomeError.message);
      } else {
        totalTransactions++;
      }
    }
    
    // Inserir despesas por categoria
    for (const [category, values] of Object.entries(historicalData.expenses)) {
      const amount = values[month];
      
      if (amount > 0) {
        const categoryMap = {
          dividas: { cat: 'Dívidas', sub: 'Financiamentos', method: 'bank_transfer' },
          impostos: { cat: 'Impostos/Taxas', sub: 'IPVA/IPTU', method: 'bank_transfer' },
          educacao: { cat: 'Educação', sub: 'IESB', method: 'credit_card' },
          compras_parceladas: { cat: 'Compras Parceladas', sub: 'Amazon/Mercado Livre', method: 'credit_card' },
          despesas_diarias: { cat: 'Despesas Diárias', sub: 'Supermercado/Restaurantes', method: 'credit_card' },
          presentes: { cat: 'Presentes', sub: 'Doações', method: 'credit_card' },
          saude: { cat: 'Saúde', sub: 'Academia/Farmácia', method: 'credit_card' },
          casa: { cat: 'Casa', sub: 'Manutenção', method: 'other' },
          seguro: { cat: 'Seguro', sub: 'Veículos', method: 'bank_transfer' },
          pets: { cat: 'Animais de Estimação', sub: 'Alimentação/Veterinário', method: 'credit_card' },
          tecnologia: { cat: 'Tecnologia', sub: 'Assinaturas', method: 'credit_card' },
          transporte: { cat: 'Transporte', sub: 'Combustível', method: 'credit_card' },
          viagens: { cat: 'Viagens', sub: 'Passagens/Hotéis', method: 'credit_card' },
          servicos_publicos: { cat: 'Serviços de Utilidade Pública', sub: 'Luz/Água/Internet', method: 'bank_transfer' },
          outros: { cat: 'Outros', sub: 'Diversos', method: 'other' }
        };
        
        const catInfo = categoryMap[category];
        
        const { error: expenseError } = await supabase
          .from('transactions')
          .insert({
            user_id: userId,
            account_id: accountId,
            date: date,
            description: catInfo.sub.toUpperCase(),
            amount: amount,
            type: 'expense',
            category: catInfo.cat,
            subcategory: catInfo.sub,
            payment_method: catInfo.method,
            status: 'completed',
            is_recurring: ['dividas', 'educacao', 'casa', 'tecnologia', 'servicos_publicos'].includes(category)
          });
        
        if (expenseError) {
          console.error(`❌ Erro ao inserir despesa ${category} de ${month}:`, expenseError.message);
        } else {
          totalTransactions++;
        }
      }
    }
    
    console.log(`✅ ${month}/${year} concluído\n`);
  }
  
  console.log(`\n🎉 População concluída! ${totalTransactions} transações inseridas.`);
  
  // Verificar totais
  const { data: summary } = await supabase
    .from('transactions')
    .select('type, amount')
    .eq('user_id', userId);
  
  if (summary) {
    const totalIncome = summary.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const totalExpenses = summary.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
    const balance = totalIncome - totalExpenses;
    
    console.log('\n📊 Resumo:');
    console.log(`💰 Total de Receitas: R$ ${totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`);
    console.log(`💸 Total de Despesas: R$ ${totalExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`);
    console.log(`💚 Saldo: R$ ${balance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`);
  }
}

populateHistoricalData().catch(console.error);

