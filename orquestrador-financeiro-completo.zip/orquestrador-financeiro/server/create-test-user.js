import { supabase } from './src/config/supabase.js';
import dotenv from 'dotenv';

dotenv.config();

async function createTestUser() {
  console.log('🔄 Criando usuário de teste...');

  try {
    // Criar usuário
    const { data: user, error: userError } = await supabase
      .from('users')
      .insert([
        {
          email: 'diogo@teste.com',
          name: 'Diogo (Teste)'
        }
      ])
      .select()
      .single();

    if (userError) {
      // Se o usuário já existe, buscar
      if (userError.code === '23505') {
        console.log('⚠️  Usuário já existe, buscando...');
        const { data: existingUser } = await supabase
          .from('users')
          .select()
          .eq('email', 'diogo@teste.com')
          .single();
        
        console.log('✅ Usuário encontrado:', existingUser.id);
        console.log('   Email:', existingUser.email);
        console.log('   Nome:', existingUser.name);
        
        // Criar conta bancária BB se não existir
        await createBankAccount(existingUser.id);
        return;
      }
      throw userError;
    }

    console.log('✅ Usuário criado com sucesso!');
    console.log('   ID:', user.id);
    console.log('   Email:', user.email);
    console.log('   Nome:', user.name);

    // Criar conta bancária do Banco do Brasil
    await createBankAccount(user.id);

  } catch (error) {
    console.error('❌ Erro ao criar usuário:', error);
  }
}

async function createBankAccount(userId) {
  console.log('\n🔄 Criando conta bancária BB...');

  try {
    const { data: account, error: accountError } = await supabase
      .from('bank_accounts')
      .insert([
        {
          user_id: userId,
          bank_code: '001',
          bank_name: 'Banco do Brasil',
          agency: '4204',
          account: '21814',
          account_type: 'checking',
          is_primary: true,
          is_active: true
        }
      ])
      .select()
      .single();

    if (accountError) {
      if (accountError.code === '23505') {
        console.log('⚠️  Conta bancária já existe');
        const { data: existingAccount } = await supabase
          .from('bank_accounts')
          .select()
          .eq('user_id', userId)
          .eq('bank_code', '001')
          .single();
        
        console.log('✅ Conta encontrada:', existingAccount.id);
        console.log('   Banco:', existingAccount.bank_name);
        console.log('   Agência:', existingAccount.agency);
        console.log('   Conta:', existingAccount.account);
        return;
      }
      throw accountError;
    }

    console.log('✅ Conta bancária criada com sucesso!');
    console.log('   ID:', account.id);
    console.log('   Banco:', account.bank_name);
    console.log('   Agência:', account.agency);
    console.log('   Conta:', account.account);

  } catch (error) {
    console.error('❌ Erro ao criar conta bancária:', error);
  }
}

createTestUser();

