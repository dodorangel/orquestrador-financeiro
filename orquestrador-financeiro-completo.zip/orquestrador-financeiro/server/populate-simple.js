import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const userId = '50ab65c7-e7ad-4858-8d2e-723cba7d0842';
const accountId = 'a0dc2ab4-a61d-4a40-8418-719de2bd6e45';

// Dados mensais simplificados (Jan-Nov 2025)
const monthlyData = [
  { month: 1, income: 20502, expenses: 28000 },
  { month: 2, income: 19982, expenses: 17500 },
  { month: 3, income: 18482, expenses: 16200 },
  { month: 4, income: 14482, expenses: 15800 },
  { month: 5, income: 14482, expenses: 14900 },
  { month: 6, income: 14482, expenses: 16500 },
  { month: 7, income: 14482, expenses: 15800 },
  { month: 8, income: 19982, expenses: 14600 },
  { month: 9, income: 14482, expenses: 13200 },
  { month: 10, income: 19982, expenses: 12800 },
  { month: 11, income: 14482, expenses: 14200 }
];

// Categorias de despesas com distribuição percentual
const expenseCategories = [
  { name: 'Supermercado', percent: 0.25, method: 'credit_card' },
  { name: 'Restaurantes', percent: 0.10, method: 'credit_card' },
  { name: 'Dívidas', percent: 0.15, method: 'bank_transfer' },
  { name: 'Aluguel', percent: 0.20, method: 'bank_transfer' },
  { name: 'Transporte', percent: 0.08, method: 'credit_card' },
  { name: 'Educação', percent: 0.10, method: 'credit_card' },
  { name: 'Saúde', percent: 0.05, method: 'credit_card' },
  { name: 'Lazer', percent: 0.04, method: 'credit_card' },
  { name: 'Pet Shop', percent: 0.03, method: 'credit_card' }
];

async function populateData() {
  console.log('🚀 Iniciando população de dados...\n');
  
  let totalTransactions = 0;
  
  for (const data of monthlyData) {
    const date = `2025-${String(data.month).padStart(2, '0')}-15`;
    
    console.log(`📅 Mês ${data.month}/2025...`);
    
    // Inserir receita
    const { error: incomeError } = await supabase
      .from('transactions')
      .insert({
        user_id: userId,
        account_id: accountId,
        date: date,
        description: 'SALARIO SERVIDOR PUBLICO',
        amount: data.income,
        type: 'income',
        payment_method: 'bank_transfer',
        status: 'completed',
        is_recurring: true
      });
    
    if (incomeError) {
      console.error(`❌ Erro receita:`, incomeError.message);
    } else {
      totalTransactions++;
    }
    
    // Inserir despesas por categoria
    for (const category of expenseCategories) {
      const amount = Math.round(data.expenses * category.percent * 100) / 100;
      
      const { error: expenseError } = await supabase
        .from('transactions')
        .insert({
          user_id: userId,
          account_id: accountId,
          date: date,
          description: category.name.toUpperCase(),
          amount: amount,
          type: 'expense',
          payment_method: category.method,
          status: 'completed',
          is_recurring: ['Dívidas', 'Aluguel', 'Educação'].includes(category.name)
        });
      
      if (expenseError) {
        console.error(`❌ Erro ${category.name}:`, expenseError.message);
      } else {
        totalTransactions++;
      }
    }
    
    console.log(`✅ Mês ${data.month} concluído\n`);
  }
  
  console.log(`\n🎉 ${totalTransactions} transações inseridas!`);
  
  // Resumo
  const { data: summary } = await supabase
    .from('transactions')
    .select('type, amount')
    .eq('user_id', userId);
  
  if (summary) {
    const totalIncome = summary.filter(t => t.type === 'income').reduce((sum, t) => sum + Number(t.amount), 0);
    const totalExpenses = summary.filter(t => t.type === 'expense').reduce((sum, t) => sum + Number(t.amount), 0);
    
    console.log('\n📊 Resumo:');
    console.log(`💰 Receitas: R$ ${totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`);
    console.log(`💸 Despesas: R$ ${totalExpenses.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`);
    console.log(`💚 Saldo: R$ ${(totalIncome - totalExpenses).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`);
  }
}

populateData().catch(console.error);

